import React from "react";

const Contact = () => {
  return (
    <div className="page">
      <h2>Contact Me</h2>
      <p>For aligned inquiries, reach out via the contact form.</p>
    </div>
  );
};

export default Contact;
