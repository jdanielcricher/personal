import React from "react";

const About = () => {
  return (
    <div className="page">
      <h2>About Me</h2>
      <p>Afrofuturist writer, philosopher, and system disruptor.</p>
    </div>
  );
};

export default About;
