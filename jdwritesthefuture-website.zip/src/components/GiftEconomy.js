import React from "react";

const GiftEconomy = () => {
  return (
    <div className="page">
      <h2>Gift Economy</h2>
      <p>I operate in a gift economy. If my work has provided value, you are welcome to contribute in alignment with your means and values.</p>
    </div>
  );
};

export default GiftEconomy;
