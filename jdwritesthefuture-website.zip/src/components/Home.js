import React from "react";

const Home = () => {
  return (
    <div className="page">
      <h2>Welcome to My Digital Home</h2>
      <p>Building the future I want to live in.</p>
    </div>
  );
};

export default Home;
