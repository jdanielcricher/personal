import React from "react";

const Writing = () => {
  return (
    <div className="page">
      <h2>Writing & Thought Leadership</h2>
      <p>Essays, philosophy, and decolonized knowledge.</p>
    </div>
  );
};

export default Writing;
