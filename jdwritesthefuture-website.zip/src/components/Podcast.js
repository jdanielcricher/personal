import React from "react";

const Podcast = () => {
  return (
    <div className="page">
      <h2>Dharma Plus Dissent Podcast</h2>
      <p>Deep conversations on spirituality, activism, and system disruption.</p>
    </div>
  );
};

export default Podcast;
